import React from "react";

const Logout = () => {
  return <div>Logged out</div>;
};

export default Logout;
